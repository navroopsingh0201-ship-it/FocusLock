# FocusLock — Android MVP starter

FocusLock is an Android-first focus timer and app-pausing prototype. It is built with Kotlin + Jetpack Compose. A normal website/PWA cannot pause other Android apps; native Android permissions are required.

## Included in this project

- Daily focus schedule enabled by default after first-time setup, initially **6 hours at 9:00 AM**. Users can change the time and duration.
- Optional **visible** gradual plan: +1 hour per day, up to 10 hours. It is OFF by default and the dashboard shows today's and tomorrow's targets. FocusLock never secretly changes a user's timer.
- Selectable list of known short-video/social apps: YouTube, Instagram, TikTok, Snapchat, Facebook, Threads, ShareChat, Moj and Josh.
- WhatsApp is excluded and always remains available. This version does not claim to separate WhatsApp calls from chats; Android package-level app blocking cannot reliably do that.
- A focus blocker screen with an emergency exit. A user can always end a session; there is no hidden forced extension. The warning offers an optional +1-hour choice, capped at 10 hours.
- One-time protection setup. The Android Accessibility Service reads only the package name attached to a window-change event; it does not retrieve screen content, messages, passwords, taps or text.
- Optional anonymous installation analytics. It is OFF by default. If enabled, the app sends only a random installation UUID and app version to your server. It does not send a name, email, phone number, selected-app list, messages or screen content.
- A Supabase database schema, rate-limited Node API, and private admin counts page.

## Important limitations (read before distributing)

1. **This is an MVP starter, not a verified production APK.** The current workspace does not have the Android SDK/Gradle build environment, so I could not compile or test it on a physical phone. Device testing is required.
2. Android app blocking requires the user to explicitly enable FocusLock under Android Settings → Accessibility. The user can disable this permission at any time. Some manufacturers may stop or delay background services.
3. Android has no universal system API that identifies every app containing a Reels/Shorts-style feed. The current version blocks the packages in `FocusStore.knownApps`; adding other apps requires updating and testing the supported package list.
4. WhatsApp is always excluded. Reliably allowing only WhatsApp call screens while blocking chat screens is not supported by this package-level MVP.
5. The daily schedule uses an **inexact** Android alarm to avoid requesting exact-alarm access. Android may batch/delay it to save battery; it is not guaranteed to trigger at the exact minute.
6. The Accessibility Service is a sensitive permission and app-store review requirements can change. Review current Google Play policy and Android requirements before public distribution. Do not describe this MVP as a firewall or as impossible to bypass.
7. No software can honestly guarantee that data will “never leak”. This starter minimizes data collection; the optional analytics endpoint must be secured, hosted with HTTPS, monitored and penetration-tested before production use.

## Open the Android project

1. Install Android Studio with Android SDK Platform 36 and JDK 17.
2. Extract this folder.
3. In Android Studio choose **Open** and select the `FocusLock` folder (the folder containing `settings.gradle.kts`).
4. Allow Gradle sync to finish. If prompted, use Gradle 8.13 and Android Gradle Plugin 8.13.2.
5. Connect an Android phone with USB debugging enabled, or start an emulator, then press **Run**.
6. On first launch, read the permission explanation, open Android Accessibility settings, enable **FocusLock app blocking**, then return and continue.
7. Test with a non-essential app first. Confirm the emergency exit works before enabling a long scheduled session.

The Gradle wrapper properties are included. If Android Studio reports that wrapper launcher files are missing, use Android Studio's Gradle wrapper generation/update action or install Gradle 8.13 and run `gradle wrapper --gradle-version 8.13` from this directory.

## Configure the anonymous user-count database

### 1. Create a Supabase project

Create a project in Supabase. Open its SQL Editor and run `backend/schema.sql`.

### 2. Start the API

```powershell
cd backend
Copy-Item .env.example .env
notepad .env
npm install
npm start
```

Fill `.env` with:

- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY` — server only; never place this key in the Android app or a public website.
- `ADMIN_TOKEN` — a long random secret.

Deploy this Node API behind HTTPS before real users connect. Keep `.env` out of Git.

### 3. Point the Android app to the API

In `app/build.gradle.kts`, replace `https://YOUR_API_DOMAIN` in `TELEMETRY_BASE_URL` with your HTTPS API base URL, then sync Gradle and rebuild.

Analytics is OFF by default. Users must turn on **Share anonymous usage count** in Settings. The admin endpoint reports opted-in install IDs and recent activity; these are not verified unique people.

### 4. View counts

Open `backend/admin.html` in a browser, enter your API base URL and admin token, and load the counts. Do not publish the admin page with a token embedded in it.

## Privacy and safety design

- App selection and timer settings stay locally on the device.
- The blocker checks package names only, not text/content.
- WhatsApp remains unblocked.
- Analytics is opt-in and can be switched off.
- The backend stores a random install ID and timestamps, not contact or message data.
- The user always has an emergency exit and can disable Android's special access.
- All listed features are included without a Premium tier or paid feature gate.

## Main project files

- `app/src/main/java/com/focuslock/app/MainActivity.kt` — UI, settings, timer controls
- `FocusStore.kt` — local preferences, selected apps and timer state
- `FocusAccessibilityService.kt` — package-name-only app pausing logic
- `FocusScheduler.kt` / receivers — daily start and end alarms
- `BlockedActivity.kt` — pause screen and emergency exit
- `AnalyticsClient.kt` — optional anonymous heartbeat
- `backend/` — Supabase SQL, Node API and admin statistics page
