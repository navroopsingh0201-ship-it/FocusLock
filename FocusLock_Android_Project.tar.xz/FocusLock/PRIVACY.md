# FocusLock privacy notes (MVP)

FocusLock's Android blocker observes only the package name associated with Android window-state events while its Accessibility Service is enabled. It does not request access to window contents and does not read screen text, chats, passwords, keystrokes, or notifications.

Timer preferences and selected package names are stored locally. WhatsApp is excluded from the blocked list.

Anonymous analytics is disabled by default. When a user turns it on, FocusLock sends a random installation UUID and app version to the configured API. The API stores first-seen and last-seen timestamps. It does not receive names, email addresses, phone numbers, device advertising IDs, selected app names, or screen activity. Users can opt out in Settings. A random installation ID is pseudonymous data, not proof of a unique human.

Do not add advertising IDs, contact details, message content, location, or per-app activity logs without a separate privacy review and a clear consent flow. Use HTTPS, keep the Supabase service-role key on the server only, rotate admin credentials, and define a retention/deletion policy before release.

No app can truthfully promise that data will never leak. This document describes the current MVP behavior, not a security certification.
